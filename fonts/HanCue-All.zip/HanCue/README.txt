HanCue — Hangul, with a little help above.

Three typefaces: Serif (Nanum Myeongjo), Sans (Nanum Gothic),
and Script (Nanum Pen Script), with Latin syllable cues added.

Install the .ttf files in TTF/ on your computer. Use the .woff2
files in WOFF2/ on your website. Each font is Regular weight.
Cues are syllable-by-syllable approximations of pronunciation.

All font files and modifications are licensed under the SIL
Open Font License 1.1. See licenses/ and NOTICE.md. Keep the
original notices and licenses with redistributed font files.

Created by @yrezgui (https://github.com/yrezgui) with AI,
inspired by Furifont (https://furifont.antfu.me/).
